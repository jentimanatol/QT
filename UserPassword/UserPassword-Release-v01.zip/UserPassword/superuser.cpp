#include "superuser.h"

SuperUser::SuperUser(const std::string& username, const std::string& password)
    : User(username, password) {}
