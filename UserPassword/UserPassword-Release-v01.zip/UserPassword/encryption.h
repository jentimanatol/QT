#ifndef ENCRYPTION_H
#define ENCRYPTION_H

#include <string>

std::string encrypt(const std::string& str);
std::string decrypt(const std::string& str);

#endif // ENCRYPTION_H
